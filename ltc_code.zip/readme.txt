This code accompanies the book
Learn to Code by Solving Problems: A Python Programming Primer
by
Daniel Zingaro

https://nostarch.com/learn-code-solving-problems


v1.3: alternate Ch8 Common Words code; minor Ch7 code cleanup; more Ch4/8 alternate solutions
v1.2: minor Ch 3/6/9 code cleanup; more Ch 10 slow code; more Ch5 alternate solutions
v1.1: add additional alternate solution for Lifeguards; use f-strings in some USACO solutions
