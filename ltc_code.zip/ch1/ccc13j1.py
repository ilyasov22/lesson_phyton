youngest = int(input())
middle = int(input())

print(middle + (middle - youngest))
