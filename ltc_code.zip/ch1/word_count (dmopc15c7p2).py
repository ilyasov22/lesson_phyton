line = input()
total_words = line.count(' ') + 1
print(total_words)
