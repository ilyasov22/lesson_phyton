num = int(input())

result = 'sp' + 'o' * num + 'ky'

print(result)
