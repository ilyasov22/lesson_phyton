num_far = int(input())

result = 'A long time ago in a galaxy '
result = result + 'far, ' * (num_far - 1)
result = result + 'far '
result = result + 'away...'

print(result)
