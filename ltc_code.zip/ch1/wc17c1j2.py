c = int(input())

f = 9 * c / 5 + 32

print(f)
